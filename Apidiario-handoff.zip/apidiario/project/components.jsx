// Apidiario — shared inspection components
// All components follow DESIGN.md tokens. NEVER hand-draw bees, hexagons,
// honey drops, or any decorative imagery.

const { useState, useRef, useEffect } = React;

// ─────────────────────────────────────────────────────────────
// Lucide-style icons (stroke 1.75 per DESIGN.md §5)
// Only used here; in real codebase will be `import { X } from 'lucide-react'`
// ─────────────────────────────────────────────────────────────
const Icon = ({ d, size = 24, fill = "none" }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill={fill}
    stroke="currentColor"
    strokeWidth="1.75"
    strokeLinecap="round"
    strokeLinejoin="round"
    aria-hidden="true"
  >
    {typeof d === "string" ? <path d={d} /> : d}
  </svg>
);

const I = {
  Crown: (p) => <Icon {...p} d="M2 18h20M4 18l-1-9 5 4 4-7 4 7 5-4-1 9" />,
  CrownOff: (p) => (
    <Icon
      {...p}
      d={
        <>
          <path d="M2 4l20 20" />
          <path d="M4 18l-1-9 4 3" />
          <path d="M22 18l-1-9-5 4" />
          <path d="M8 18h14" />
        </>
      }
    />
  ),
  HelpCircle: (p) => (
    <Icon
      {...p}
      d={
        <>
          <circle cx="12" cy="12" r="9" />
          <path d="M9.5 9a2.5 2.5 0 1 1 3.5 2.3c-1 .5-1 1.2-1 2" />
          <circle cx="12" cy="17" r="0.6" fill="currentColor" />
        </>
      }
    />
  ),
  Egg: (p) => <Icon {...p} d="M12 3c-3.5 0-6 5-6 10a6 6 0 0 0 12 0c0-5-2.5-10-6-10z" />,
  Larva: (p) => (
    <Icon
      {...p}
      d={
        <>
          <path d="M5 14c0-3 2.5-5 7-5s7 2 7 5-2.5 5-7 5-7-2-7-5z" />
          <path d="M9 12.5v3M13 12.5v3" />
        </>
      }
    />
  ),
  Capped: (p) => (
    <Icon
      {...p}
      d={
        <>
          <circle cx="12" cy="12" r="9" />
          <path d="M3 12h18" />
        </>
      }
    />
  ),
  Plus: (p) => <Icon {...p} d="M12 5v14M5 12h14" />,
  Minus: (p) => <Icon {...p} d="M5 12h14" />,
  Mic: (p) => (
    <Icon
      {...p}
      d={
        <>
          <rect x="9" y="2" width="6" height="12" rx="3" />
          <path d="M5 11a7 7 0 0 0 14 0M12 18v3" />
        </>
      }
    />
  ),
  ChevronDown: (p) => <Icon {...p} d="M6 9l6 6 6-6" />,
  ChevronLeft: (p) => <Icon {...p} d="M15 6l-6 6 6 6" />,
  X: (p) => <Icon {...p} d="M6 6l12 12M18 6l-12 12" />,
  Cloud: (p) => (
    <Icon
      {...p}
      d="M7 18a4 4 0 0 1 0-8 6 6 0 0 1 11.5 1.5A3.5 3.5 0 0 1 18 18H7z"
    />
  ),
  Sun: (p) => (
    <Icon
      {...p}
      d={
        <>
          <circle cx="12" cy="12" r="4" />
          <path d="M12 2v2M12 20v2M4.93 4.93l1.4 1.4M17.66 17.66l1.4 1.4M2 12h2M20 12h2M4.93 19.07l1.4-1.4M17.66 6.34l1.4-1.4" />
        </>
      }
    />
  ),
  Camera: (p) => (
    <Icon
      {...p}
      d={
        <>
          <path d="M3 8h4l2-3h6l2 3h4v11H3z" />
          <circle cx="12" cy="13" r="4" />
        </>
      }
    />
  ),
  Save: (p) => (
    <Icon
      {...p}
      d={
        <>
          <path d="M5 3h11l4 4v14H5z" />
          <path d="M8 3v6h8V3M8 14h8v7H8z" />
        </>
      }
    />
  ),
  AlertTriangle: (p) => (
    <Icon
      {...p}
      d={
        <>
          <path d="M12 3l10 17H2z" />
          <path d="M12 10v5M12 18v.5" />
        </>
      }
    />
  ),
  ShieldAlert: (p) => (
    <Icon
      {...p}
      d={
        <>
          <path d="M12 3l8 3v6c0 4.5-3.5 8-8 9-4.5-1-8-4.5-8-9V6z" />
          <path d="M12 8v5M12 16v.5" />
        </>
      }
    />
  ),
  Activity: (p) => <Icon {...p} d="M3 12h4l3-8 4 16 3-8h4" />,
  Flower: (p) => (
    <Icon
      {...p}
      d={
        <>
          <circle cx="12" cy="12" r="2.5" />
          <path d="M12 2c2 1 2 5 0 7-2-2-2-6 0-7zM12 22c-2-1-2-5 0-7 2 2 2 6 0 7zM2 12c1-2 5-2 7 0-2 2-6 2-7 0zM22 12c-1 2-5 2-7 0 2-2 6-2 7 0z" />
        </>
      }
    />
  ),
  Droplet: (p) => <Icon {...p} d="M12 3l5 7a5 5 0 1 1-10 0z" />,
  Map: (p) => (
    <Icon
      {...p}
      d={
        <>
          <path d="M3 6l6-2 6 2 6-2v14l-6 2-6-2-6 2z" />
          <path d="M9 4v16M15 6v16" />
        </>
      }
    />
  ),
  ArrowLeft: (p) => <Icon {...p} d="M19 12H5M12 19l-7-7 7-7" />,
  MoreVertical: (p) => (
    <Icon
      {...p}
      d={
        <>
          <circle cx="12" cy="5" r="0.6" fill="currentColor" />
          <circle cx="12" cy="12" r="0.6" fill="currentColor" />
          <circle cx="12" cy="19" r="0.6" fill="currentColor" />
        </>
      }
    />
  ),
};

// ─────────────────────────────────────────────────────────────
// Existing components (mirroring src/components/ui/*)
// ─────────────────────────────────────────────────────────────

function Button({ variant = "primary", size = "md", className = "", children, ...props }) {
  const variants = {
    primary: "bg-honey-500 text-cream-50 hover:bg-honey-600 active:bg-honey-700",
    secondary: "bg-cream-200 text-wood-700 border border-wood-400/40 hover:bg-cream-100",
    ghost: "bg-transparent text-wood-700 hover:bg-cream-100",
    destructive: "bg-danger-500 text-cream-50",
  };
  const sizes = {
    sm: "h-9 px-3 text-sm",
    md: "h-11 px-4 text-base",
    lg: "h-13 px-6 text-base",
  };
  return (
    <button
      className={`inline-flex items-center justify-center gap-2 rounded-md font-medium transition-colors duration-150 select-none ${variants[variant]} ${sizes[size]} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}

function Card({ className = "", children }) {
  return (
    <div className={`bg-cream-100 border border-cream-200 rounded-lg p-4 shadow-xs ${className}`}>
      {children}
    </div>
  );
}

function StatusDot({ status, label, showLabel = false, className = "" }) {
  const cls = {
    success: "bg-success-500",
    warning: "bg-warning-500",
    danger: "bg-danger-500",
    info: "bg-honey-500",
    neutral: "bg-wood-400",
  }[status];
  return (
    <span className={`inline-flex items-center gap-1.5 ${className}`}>
      <span className={`inline-block size-2 rounded-full shrink-0 ${cls}`} aria-hidden="true" />
      <span className={showLabel ? "text-sm text-wood-500" : "sr-only"}>{label}</span>
    </span>
  );
}

function IconBadge({ icon, color = "wood", size = "sm" }) {
  const colors = {
    success: "bg-success-100 text-success-500",
    warning: "bg-warning-100 text-warning-500",
    danger: "bg-danger-100 text-danger-500",
    honey: "bg-honey-300/30 text-honey-600",
    wood: "bg-cream-200 text-wood-500",
  };
  const sizes = { sm: "size-8", md: "size-10" };
  return (
    <div className={`flex items-center justify-center rounded-full shrink-0 ${colors[color]} ${sizes[size]}`}>
      {icon}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// New components (proposed names confirmed)
// ─────────────────────────────────────────────────────────────

// SegmentedControl — pill-style with sliding indicator (DESIGN.md §6)
// active+confirmed = solid cream-50 thumb, active+prefilled = same thumb but
// without shadow (sits inside; not yet committed).
function SegmentedControl({ options, value, onChange, ariaLabel, dirty = true }) {
  return (
    <div
      role="radiogroup"
      aria-label={ariaLabel}
      className="flex items-center bg-cream-200 p-1 rounded-md w-full"
    >
      {options.map((opt) => {
        const active = opt.value === value;
        let cls;
        if (active && dirty) cls = "bg-cream-50 shadow-xs text-wood-800";
        else if (active && !dirty)
          cls = "bg-cream-50/60 text-wood-700 border border-dashed border-honey-500/60";
        else cls = "text-wood-500";
        return (
          <button
            key={opt.value}
            role="radio"
            aria-checked={active}
            onClick={() => onChange?.(opt.value)}
            style={{ flex: "1 1 0%" }}
            className={`h-10 px-3 text-sm font-medium rounded transition-colors duration-150 ${cls}`}
          >
            {opt.label}
          </button>
        );
      })}
    </div>
  );
}

// QueenSightingPicker — 3 large tiles (vista / non vista / non cercata)
// confirmed = solid honey fill, prefilled = tenue honey fill (border only).
function QueenSightingPicker({ value, onChange, dirty = true }) {
  const opts = [
    { value: "vista", label: "Vista", icon: <I.Crown size={32} /> },
    { value: "non_vista", label: "Non vista", icon: <I.CrownOff size={32} /> },
    { value: "non_cercata", label: "Non cercata", icon: <I.HelpCircle size={32} /> },
  ];
  return (
    <div role="radiogroup" aria-label="Regina" className="grid grid-cols-3 gap-2">
      {opts.map((o) => {
        const active = value === o.value;
        let cls;
        if (active && dirty) cls = "bg-honey-300/60 border-honey-500 text-wood-800";
        else if (active && !dirty) cls = "bg-honey-300/15 border-honey-500 border-dashed text-wood-700";
        else cls = "bg-cream-50 border-cream-200 text-wood-500";
        return (
          <button
            key={o.value}
            role="radio"
            aria-checked={active}
            onClick={() => onChange?.(o.value)}
            className={`h-[88px] rounded-lg border flex flex-col items-center justify-center gap-1.5 transition-all duration-150 ${cls}`}
          >
            {o.icon}
            <span className="text-xs font-medium">{o.label}</span>
          </button>
        );
      })}
    </div>
  );
}

// BroodStageToggles — 3 independent toggles (uova / larve / opercolata)
// on+confirmed = solid honey, on+prefilled = tenue + dashed border.
function BroodStageToggles({ value = {}, onChange, dirty = true }) {
  const stages = [
    { key: "uova", label: "Uova", icon: <I.Egg size={28} /> },
    { key: "larve", label: "Larve", icon: <I.Larva size={28} /> },
    { key: "opercolata", label: "Opercolata", icon: <I.Capped size={28} /> },
  ];
  return (
    <div className="grid grid-cols-3 gap-2">
      {stages.map((s) => {
        const on = !!value[s.key];
        let cls;
        if (on && dirty) cls = "bg-honey-300/60 border-honey-500 text-wood-800";
        else if (on && !dirty) cls = "bg-honey-300/15 border-honey-500 border-dashed text-wood-700";
        else cls = "bg-cream-50 border-cream-200 text-wood-400";
        return (
          <button
            key={s.key}
            aria-pressed={on}
            onClick={() => onChange?.({ ...value, [s.key]: !on })}
            className={`h-[76px] rounded-lg border flex flex-col items-center justify-center gap-1 transition-all duration-150 ${cls}`}
          >
            {s.icon}
            <span className="text-xs font-medium">{s.label}</span>
          </button>
        );
      })}
    </div>
  );
}

// FrameCounter — supports two orientations
//   horizontal: stacked label + stepper (used in narrow grids, deprecated for Express)
//   row: full-width row with label left, stepper right (preferred for Express)
function FrameCounter({ label, value, onChange, dirty = true, min = 0, max = 20, orientation = "row" }) {
  const dec = () => onChange?.(Math.max(min, value - 1));
  const inc = () => onChange?.(Math.min(max, value + 1));

  const numCls = [
    "text-xl font-semibold tracking-tight min-w-[24px] text-center",
    dirty ? "text-wood-800" : "text-wood-500",
  ].join(" ");

  const decBtn = (
    <button
      onClick={dec}
      aria-label={`Diminuisci ${label}`}
      className="size-11 flex items-center justify-center text-wood-500 hover:text-wood-700 active:bg-cream-200 rounded transition-colors disabled:text-wood-300"
      disabled={value <= min}
    >
      <I.Minus size={20} />
    </button>
  );
  const incBtn = (
    <button
      onClick={inc}
      aria-label={`Aumenta ${label}`}
      className="size-11 flex items-center justify-center text-wood-500 hover:text-wood-700 active:bg-cream-200 rounded transition-colors disabled:text-wood-300"
      disabled={value >= max}
    >
      <I.Plus size={20} />
    </button>
  );

  if (orientation === "row") {
    return (
      <div className="flex items-center gap-3 bg-cream-50 border border-cream-200 rounded-md h-12 pl-4 pr-1">
        <span className="text-sm font-medium text-wood-700 flex-1">{label}</span>
        <div className="flex items-center">
          {decBtn}
          <span className={numCls} style={{ fontVariantNumeric: "tabular-nums" }}>{value}</span>
          {incBtn}
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center gap-2 flex-1">
      <span className="text-xs font-medium text-wood-500">{label}</span>
      <div className="flex items-center justify-between w-full bg-cream-50 border border-cream-200 rounded-md h-12 px-1">
        {decBtn}
        <span className={numCls} style={{ fontVariantNumeric: "tabular-nums" }}>{value}</span>
        {incBtn}
      </div>
    </div>
  );
}

// QueenCellsSelector — 4 exclusive states with semantic dots
// active+confirmed = solid honey fill, active+prefilled = tenue + dashed.
function QueenCellsSelector({ value, onChange, dirty = true }) {
  const opts = [
    { value: "nessuna", label: "Nessuna", status: "neutral" },
    { value: "scorta", label: "Di scorta", status: "neutral" },
    { value: "sciamatura", label: "Sciamatura", status: "warning" },
    { value: "sostituzione", label: "Sostituzione", status: "info" },
  ];
  return (
    <div role="radiogroup" aria-label="Celle reali" className="grid grid-cols-2 gap-2">
      {opts.map((o) => {
        const active = value === o.value;
        let cls;
        if (active && dirty) cls = "bg-honey-300/60 border-honey-500 text-wood-800";
        else if (active && !dirty) cls = "bg-honey-300/15 border-honey-500 border-dashed text-wood-700";
        else cls = "bg-cream-50 border-cream-200 text-wood-500";
        return (
          <button
            key={o.value}
            role="radio"
            aria-checked={active}
            onClick={() => onChange?.(o.value)}
            className={`h-12 rounded-md border flex items-center gap-2.5 px-3 transition-all duration-150 ${cls}`}
          >
            <StatusDot status={o.status} label={o.label} />
            <span className="text-sm font-medium">{o.label}</span>
          </button>
        );
      })}
    </div>
  );
}

// PathologyChip — selectable chip
// confirmed = solid danger-100 fill, prefilled = tenue + dashed border.
function PathologyChip({ label, selected, onClick, dirty = true, tone = "danger" }) {
  const tones = {
    danger: {
      solid: "bg-danger-100 border-danger-500/40 text-danger-500",
      tenue: "bg-danger-100/40 border-danger-500/40 border-dashed text-danger-500",
    },
    honey: {
      solid: "bg-honey-300/60 border-honey-500 text-wood-800",
      tenue: "bg-honey-300/15 border-honey-500 border-dashed text-wood-700",
    },
  };
  const t = tones[tone];
  let cls;
  if (selected && dirty) cls = t.solid;
  else if (selected && !dirty) cls = t.tenue;
  else cls = "bg-cream-50 border-cream-200 text-wood-500 hover:text-wood-700";
  return (
    <button
      onClick={onClick}
      aria-pressed={selected}
      className={`h-9 px-3.5 rounded-full border text-sm font-medium whitespace-nowrap transition-all duration-150 shrink-0 ${cls}`}
    >
      {label}
    </button>
  );
}

// InspectionNoteField — collapsed note input with mic affordance
function InspectionNoteField({ value, expanded, onExpand, onChange, dirty = true }) {
  if (!expanded) {
    return (
      <button
        onClick={onExpand}
        className="w-full h-12 bg-cream-50 border border-cream-200 rounded-md px-4 flex items-center justify-between text-left transition-colors hover:border-wood-400/40"
      >
        <span className={`text-sm ${value ? (dirty ? "text-wood-700" : "text-wood-500") : "text-wood-400"}`}>
          {value || "Aggiungi nota o detta…"}
        </span>
        <I.Mic size={20} />
      </button>
    );
  }
  return (
    <div className="bg-cream-50 border border-cream-200 rounded-md focus-within:border-honey-500 focus-within:ring-2 focus-within:ring-honey-500/20">
      <textarea
        value={value || ""}
        onChange={(e) => onChange?.(e.target.value)}
        autoFocus
        rows={4}
        placeholder="Aggiungi nota o detta…"
        className="w-full bg-transparent px-4 py-3 text-sm text-wood-700 placeholder:text-wood-400 focus:outline-none resize-none"
      />
      <div className="flex items-center justify-between border-t border-cream-200 px-2 py-1.5">
        <button className="size-9 flex items-center justify-center text-wood-500 hover:text-wood-700 rounded">
          <I.Mic size={18} />
        </button>
        <span className="text-xs text-wood-400 pr-2">{(value || "").length} caratteri</span>
      </div>
    </div>
  );
}

// InspectionHeader — sticky top header
function InspectionHeader({ apiary, hive, datetime, weather }) {
  return (
    <header className="sticky top-0 z-10 bg-cream-50/95 backdrop-blur-sm border-b border-cream-200">
      <div className="flex items-center gap-3 h-14 px-2">
        <button
          aria-label="Indietro"
          className="size-11 flex items-center justify-center text-wood-700 hover:bg-cream-100 rounded-md"
        >
          <I.ArrowLeft size={22} />
        </button>
        <div className="flex-1 min-w-0">
          <div className="text-sm font-semibold text-wood-800 truncate">
            {apiary} · <span className="text-honey-600">{hive}</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-wood-500">
            <span>{datetime}</span>
            {weather && (
              <>
                <span aria-hidden="true">·</span>
                <span className="inline-flex items-center gap-1">
                  {weather.icon}
                  <span>{weather.temp}</span>
                </span>
              </>
            )}
          </div>
        </div>
        <button
          aria-label="Altre opzioni"
          className="size-11 flex items-center justify-center text-wood-500 hover:bg-cream-100 rounded-md"
        >
          <I.MoreVertical size={20} />
        </button>
      </div>
    </header>
  );
}

// PrefillBanner — info band shown when fields prefilled from last inspection
function PrefillBanner({ kind, lastDate, onReset }) {
  if (kind === "first") {
    return (
      <div className="bg-cream-100 border-b border-cream-200 px-4 py-2.5 flex items-center gap-2">
        <span className="text-xs uppercase tracking-wider font-semibold text-wood-500">
          Nuovo
        </span>
        <span className="text-sm text-wood-500">Prima ispezione di questa arnia</span>
      </div>
    );
  }
  if (kind === "prefilled") {
    return (
      <button
        onClick={onReset}
        className="w-full bg-cream-100 border-b border-cream-200 px-4 py-2.5 flex items-center justify-between text-left hover:bg-cream-200 transition-colors"
      >
        <span className="text-sm text-wood-500">
          Precompilato dall&rsquo;ispezione del <span className="font-medium text-wood-700">{lastDate}</span>
        </span>
        <span className="text-xs font-medium text-honey-600">Azzera</span>
      </button>
    );
  }
  return null;
}

// SectionLabel — small label above each form group
function SectionLabel({ children, required }) {
  return (
    <div className="flex items-baseline justify-between mb-2">
      <h3 className="text-sm font-semibold text-wood-700">{children}</h3>
      {required && <span className="text-xs text-wood-400">obbligatorio</span>}
    </div>
  );
}

// FormSubmitBar — sticky bottom CTA
function FormSubmitBar({ onCancel, onSave, saveLabel = "Salva ispezione" }) {
  return (
    <div
      className="sticky bottom-0 bg-cream-50/95 backdrop-blur-sm border-t border-cream-200 px-4 py-3 flex items-center gap-2"
      style={{ paddingBottom: "calc(0.75rem + env(safe-area-inset-bottom))" }}
    >
      <Button variant="ghost" size="md" onClick={onCancel} className="!flex-none px-4">
        Annulla
      </Button>
      <Button variant="primary" size="md" onClick={onSave} className="flex-1">
        {saveLabel}
      </Button>
    </div>
  );
}

// UnsavedChangesSheet — bottom sheet for unsaved-changes confirmation
function UnsavedChangesSheet({ open, onSave, onDiscard, onCancel }) {
  if (!open) return null;
  return (
    <>
      <div
        className="absolute inset-0 z-30"
        style={{ background: "rgba(26, 19, 12, 0.4)" }}
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Modifiche non salvate"
        className="absolute inset-x-0 bottom-0 z-40 bg-cream-50 rounded-t-xl"
        style={{ boxShadow: "0 -12px 32px rgba(60, 40, 20, 0.18)" }}
      >
        <div className="flex justify-center pt-2.5 pb-1">
          <span className="block w-9 h-1 rounded-full bg-cream-200" aria-hidden="true" />
        </div>
        <div className="px-5 pt-3 pb-4">
          <h2 className="text-lg font-semibold text-wood-800 mb-1">
            Modifiche non salvate
          </h2>
          <p className="text-sm text-wood-500 leading-relaxed">
            Hai compilato parte dell&rsquo;ispezione. Vuoi salvarla prima di uscire?
          </p>
        </div>
        <div
          className="px-4 flex flex-col gap-2 pb-4"
          style={{ paddingBottom: "calc(1rem + env(safe-area-inset-bottom))" }}
        >
          <Button variant="primary" size="lg" onClick={onSave}>
            Salva
          </Button>
          <Button variant="secondary" size="lg" onClick={onDiscard}>
            Esci senza salvare
          </Button>
          <Button variant="ghost" size="md" onClick={onCancel}>
            Annulla
          </Button>
        </div>
      </div>
    </>
  );
}

// SaveToast — confirmation toast after save
function SaveToast({ visible, message }) {
  if (!visible) return null;
  return (
    <div
      role="status"
      className="absolute left-4 right-4 bottom-20 z-20 bg-wood-800 text-cream-50 rounded-lg px-4 py-3 flex items-center gap-3 shadow-lg"
    >
      <I.Save size={18} />
      <span className="text-sm flex-1">{message}</span>
    </div>
  );
}

Object.assign(window, {
  I,
  Button,
  Card,
  StatusDot,
  IconBadge,
  SegmentedControl,
  QueenSightingPicker,
  BroodStageToggles,
  FrameCounter,
  QueenCellsSelector,
  PathologyChip,
  InspectionNoteField,
  InspectionHeader,
  PrefillBanner,
  SectionLabel,
  FormSubmitBar,
  UnsavedChangesSheet,
  SaveToast,
});
