// Apidiario — Inspection screens (5 frames, Express-lite)
// US-01 — Quick field inspection
// Express now: header + Regina + Covata + Popolazione + Note. No scroll @ 360×800.
// All fields outside Express save as NULL (= "non rilevato"), no prefill.

const julyFilled = {
  queen: "vista",
  brood: { uova: true, larve: true, opercolata: true },
  population: "forte",
  notes: "",
  // standard-only
  frames: { covata: 6, miele: 2, polline: 1 },
  supers: 1,
  queenCells: "nessuna",
  pathologies: new Set(),
  pollenIncoming: true,
  varroaCount: "",
  varroaMethod: "caduta",
  behavior: "calmo",
  interventions: new Set(["Aggiunto melario"]),
};

const lastInspectionDefaults = {
  queen: "non_cercata",
  brood: { uova: true, larve: true, opercolata: true },
  population: "media",
  notes: "",
  // standard fields stay null in express prefill semantics
  frames: { covata: 0, miele: 0, polline: 0 },
  supers: 0,
  queenCells: "nessuna",
  pathologies: new Set(),
  pollenIncoming: false,
  varroaCount: "",
  varroaMethod: "caduta",
  behavior: "calmo",
  interventions: new Set(),
};

const neutralDefaults = {
  queen: "non_cercata",
  brood: { uova: false, larve: false, opercolata: false },
  population: "media",
  notes: "",
  frames: { covata: 0, miele: 0, polline: 0 },
  supers: 0,
  queenCells: "nessuna",
  pathologies: new Set(),
  pollenIncoming: false,
  varroaCount: "",
  varroaMethod: "caduta",
  behavior: "calmo",
  interventions: new Set(),
};

const PATHOLOGY_OPTIONS = ["Varroa", "Peste americana", "Peste europea", "Covata calcificata", "Nosema", "Virus", "Altro"];
const INTERVENTION_OPTIONS = ["Aggiunto melario", "Tolto melario", "Tolto telaino", "Aggiunto telaino", "Cambio regina", "Distruzione celle", "Nutrizione"];

// ─────────────────────────────────────────────────────────────
// Express body — 4 form sections, designed to fit 360×800 w/o scroll
// ─────────────────────────────────────────────────────────────
function ExpressBody({ state, dirty }) {
  const [s, setS] = useState(state);
  const [touched, setTouched] = useState({ queen: dirty, brood: dirty, population: dirty, notes: dirty });
  const [noteOpen, setNoteOpen] = useState(false);
  const set = (k) => (v) => { setS((p) => ({ ...p, [k]: v })); setTouched((p) => ({ ...p, [k]: true })); };

  return (
    <div className="px-4 py-4 flex flex-col gap-5">
      <section>
        <SectionLabel required>Regina</SectionLabel>
        <QueenSightingPicker value={s.queen} onChange={set("queen")} dirty={touched.queen} />
      </section>
      <section>
        <SectionLabel>Covata</SectionLabel>
        <BroodStageToggles value={s.brood} onChange={set("brood")} dirty={touched.brood} />
      </section>
      <section>
        <SectionLabel required>Popolazione</SectionLabel>
        <SegmentedControl
          ariaLabel="Popolazione"
          value={s.population}
          onChange={set("population")}
          dirty={touched.population}
          options={[{ value: "debole", label: "Debole" }, { value: "media", label: "Media" }, { value: "forte", label: "Forte" }]}
        />
      </section>
      <section>
        <SectionLabel>Note</SectionLabel>
        <InspectionNoteField value={s.notes} expanded={noteOpen} onExpand={() => setNoteOpen(true)} onChange={set("notes")} dirty={touched.notes} />
      </section>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Standard body — full set per SPEC.md §6.3
// ─────────────────────────────────────────────────────────────
function StandardBody({ state }) {
  const [s, setS] = useState(state);
  const [noteOpen, setNoteOpen] = useState(true);
  const set = (k) => (v) => setS((p) => ({ ...p, [k]: v }));
  const setFrame = (k) => (v) => setS((p) => ({ ...p, frames: { ...p.frames, [k]: v } }));
  const togglePath = (l) => setS((p) => { const n = new Set(p.pathologies); n.has(l) ? n.delete(l) : n.add(l); return { ...p, pathologies: n }; });
  const toggleInt = (l) => setS((p) => { const n = new Set(p.interventions); n.has(l) ? n.delete(l) : n.add(l); return { ...p, interventions: n }; });

  return (
    <div className="px-4 py-4 flex flex-col gap-6">
      <section>
        <SectionLabel required>Regina</SectionLabel>
        <QueenSightingPicker value={s.queen} onChange={set("queen")} />
      </section>
      <section>
        <SectionLabel>Covata</SectionLabel>
        <BroodStageToggles value={s.brood} onChange={set("brood")} />
      </section>
      <section>
        <SectionLabel required>Popolazione</SectionLabel>
        <SegmentedControl ariaLabel="Popolazione" value={s.population} onChange={set("population")}
          options={[{ value: "debole", label: "Debole" }, { value: "media", label: "Media" }, { value: "forte", label: "Forte" }]} />
      </section>

      <section>
        <SectionLabel>Telaini</SectionLabel>
        <div className="flex flex-col gap-2">
          <FrameCounter label="Telaini covata" value={s.frames.covata} onChange={setFrame("covata")} orientation="row" />
          <FrameCounter label="Telaini miele" value={s.frames.miele} onChange={setFrame("miele")} orientation="row" />
          <FrameCounter label="Telaini polline" value={s.frames.polline} onChange={setFrame("polline")} orientation="row" />
          <FrameCounter label="Melari presenti" value={s.supers} onChange={set("supers")} orientation="row" min={0} max={5} />
        </div>
      </section>

      <section>
        <SectionLabel>Importazione polline</SectionLabel>
        <button onClick={() => set("pollenIncoming")(!s.pollenIncoming)} aria-pressed={s.pollenIncoming}
          className={`w-full h-12 rounded-md border px-4 flex items-center justify-between transition-colors ${s.pollenIncoming ? "bg-honey-300/60 border-honey-500 text-wood-800" : "bg-cream-50 border-cream-200 text-wood-500"}`}>
          <span className="inline-flex items-center gap-2.5 text-sm font-medium">
            <I.Flower size={18} />{s.pollenIncoming ? "Bottinatrici al lavoro" : "Nessuna importazione"}
          </span>
          <span className={`h-6 w-10 rounded-full p-0.5 transition-colors ${s.pollenIncoming ? "bg-honey-500" : "bg-cream-200"}`}>
            <span className={`block size-5 rounded-full bg-cream-50 transition-transform ${s.pollenIncoming ? "translate-x-4" : "translate-x-0"}`} />
          </span>
        </button>
      </section>

      <section>
        <SectionLabel required>Celle reali</SectionLabel>
        <QueenCellsSelector value={s.queenCells} onChange={set("queenCells")} />
      </section>

      <section>
        <SectionLabel>Comportamento</SectionLabel>
        <SegmentedControl ariaLabel="Comportamento" value={s.behavior} onChange={set("behavior")}
          options={[{ value: "calmo", label: "Calmo" }, { value: "nervoso", label: "Nervoso" }, { value: "aggressivo", label: "Aggressivo" }]} />
      </section>

      <section>
        <SectionLabel>Segni patologici</SectionLabel>
        <div className="flex gap-2 overflow-x-auto -mx-4 px-4 pb-1" style={{ scrollbarWidth: "none" }}>
          {PATHOLOGY_OPTIONS.map((p) => (
            <PathologyChip key={p} label={p} selected={s.pathologies.has(p)} onClick={() => togglePath(p)} />
          ))}
        </div>
      </section>

      <section>
        <SectionLabel>Conteggio varroa</SectionLabel>
        <div className="flex flex-col gap-2">
          <input value={s.varroaCount} onChange={(e) => set("varroaCount")(e.target.value)} type="number" placeholder="Numero acari"
            className="w-full h-12 rounded-md border border-cream-200 bg-cream-50 px-4 text-base text-wood-700 placeholder:text-wood-400 focus:border-honey-500 focus:outline-none" />
          <SegmentedControl ariaLabel="Metodo conteggio" value={s.varroaMethod} onChange={set("varroaMethod")}
            options={[{ value: "caduta", label: "Caduta" }, { value: "alcol", label: "Alcol" }, { value: "zucchero", label: "Zucchero" }, { value: "altro", label: "Altro" }]} />
        </div>
      </section>

      <section>
        <SectionLabel>Interventi eseguiti</SectionLabel>
        <div className="flex flex-wrap gap-2 mb-2">
          {INTERVENTION_OPTIONS.map((i) => (
            <PathologyChip key={i} label={i} selected={s.interventions.has(i)} onClick={() => toggleInt(i)} tone="honey" />
          ))}
        </div>
        <textarea rows={2} placeholder="Altri interventi…"
          className="w-full bg-cream-50 border border-cream-200 rounded-md px-4 py-2.5 text-sm text-wood-700 placeholder:text-wood-400 focus:border-honey-500 focus:outline-none resize-none" />
      </section>

      <section>
        <SectionLabel>Foto / video</SectionLabel>
        <div className="grid grid-cols-3 gap-2">
          {["telaino_3.jpg", "regina.jpg"].map((name) => (
            <div key={name} className="aspect-square rounded-md bg-cream-100 border border-cream-200 overflow-hidden relative">
              <div className="absolute inset-0" style={{ background: "repeating-linear-gradient(45deg, #E9DFC8 0 6px, #F5EEDE 6px 12px)" }} />
              <span className="absolute inset-0 flex items-end justify-center pb-1 text-[10px] text-wood-500" style={{ fontFamily: "ui-monospace, monospace" }}>{name}</span>
            </div>
          ))}
          <button className="aspect-square rounded-md border border-dashed border-cream-200 bg-cream-50 text-wood-500 flex flex-col items-center justify-center gap-1 hover:bg-cream-100 transition-colors">
            <I.Camera size={22} /><span className="text-xs font-medium">Aggiungi</span>
          </button>
        </div>
      </section>

      <section>
        <SectionLabel>Note</SectionLabel>
        <InspectionNoteField value={s.notes} expanded={noteOpen} onExpand={() => setNoteOpen(true)} onChange={set("notes")} />
      </section>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Inspection screen frame (used for all 5 variations)
// Now 360×800 to match new Express target.
// ─────────────────────────────────────────────────────────────
function InspectionFrame({ mode = "express", banner = null, initialState, dirtyAll = true, showSheet = false }) {
  const headerH = 24 + 56; // status + header
  const tabsH = 56;
  const bannerH = banner ? 41 : 0;
  const submitH = 68;
  return (
    <div className="relative bg-cream-50 text-wood-700 overflow-hidden" style={{ width: 360, height: 800, fontFamily: "Inter, system-ui, sans-serif" }}>
      <div className="h-6 bg-cream-50 flex items-center justify-between px-5 text-[11px] font-semibold text-wood-700">
        <span style={{ fontVariantNumeric: "tabular-nums" }}>9:42</span>
        <div className="flex items-center gap-1 text-wood-700">
          <span className="text-[10px]">●●●</span><span className="text-[10px]">4G</span>
          <span className="inline-block w-5 h-2.5 border border-wood-700 rounded-sm relative">
            <span className="absolute inset-0.5 bg-wood-700 rounded-[1px]" style={{ width: "70%" }} />
          </span>
        </div>
      </div>
      <InspectionHeader apiary="Apiario Dosso" hive="Arnia A3" datetime="Lun 14 lug · 09:42" weather={{ icon: <I.Sun size={14} />, temp: "24°" }} />
      <div className="px-4 pt-3 pb-2">
        <SegmentedControl ariaLabel="Modalità" value={mode} onChange={() => {}}
          options={[{ value: "express", label: "Express" }, { value: "standard", label: "Standard" }]} />
      </div>
      {banner && <PrefillBanner kind={banner.kind} lastDate={banner.lastDate} />}
      <div className="overflow-y-auto" style={{ height: 800 - headerH - tabsH - bannerH - submitH, scrollbarWidth: "none" }}>
        {mode === "express" ? <ExpressBody state={initialState} dirty={dirtyAll} /> : <StandardBody state={initialState} />}
      </div>
      <FormSubmitBar onCancel={() => {}} onSave={() => {}} />
      <UnsavedChangesSheet open={showSheet} onSave={() => {}} onDiscard={() => {}} onCancel={() => {}} />
    </div>
  );
}

Object.assign(window, { InspectionFrame, ExpressBody, StandardBody, julyFilled, lastInspectionDefaults, neutralDefaults });
